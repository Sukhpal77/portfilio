import React, { useState } from 'react';

export function HRMSDemo() {
  const [hrmsTab, setHrmsTab] = useState<'attendance' | 'leave' | 'payroll' | 'rbac'>('attendance');
  return (
            
            <div className="flex flex-col gap-4">
              <div className="bg-[#1e1f25] border border-white/[0.06] p-5 rounded-xl flex flex-col gap-3">
                <div className="flex items-center justify-between pb-1 border-b border-white/[0.06]">
                  <span className="font-mono text-xs text-[#bbcabf]">
                    hrms_workspace // sample data
                  </span>
                  <span className="font-mono text-[10px] text-[color:var(--accent-soft)] font-semibold">
                    RBAC ENABLED
                  </span>
                </div>

                {/* Tabs Selector */}
                <div className="flex flex-wrap gap-1 bg-[#292a2f] p-1 rounded">
                  <button
                    onClick={() => setHrmsTab('attendance')}
                    className={`px-3 py-1 rounded font-mono text-[10px] font-semibold transition-all ${
                      hrmsTab === 'attendance'
                        ? 'bg-[var(--accent-strong)] text-[#071722]'
                        : 'text-[#bbcabf] hover:text-white'
                    }`}
                  >
                    Attendance
                  </button>
                  <button
                    onClick={() => setHrmsTab('leave')}
                    className={`px-3 py-1 rounded font-mono text-[10px] font-semibold transition-all ${
                      hrmsTab === 'leave'
                        ? 'bg-[var(--accent-strong)] text-[#071722]'
                        : 'text-[#bbcabf] hover:text-white'
                    }`}
                  >
                    Leaves
                  </button>
                  <button
                    onClick={() => setHrmsTab('payroll')}
                    className={`px-3 py-1 rounded font-mono text-[10px] font-semibold transition-all ${
                      hrmsTab === 'payroll'
                        ? 'bg-[var(--accent-strong)] text-[#071722]'
                        : 'text-[#bbcabf] hover:text-white'
                    }`}
                  >
                    Payroll
                  </button>
                  <button
                    onClick={() => setHrmsTab('rbac')}
                    className={`px-3 py-1 rounded font-mono text-[10px] font-semibold transition-all ${
                      hrmsTab === 'rbac'
                        ? 'bg-[var(--accent-strong)] text-[#071722]'
                        : 'text-[#bbcabf] hover:text-white'
                    }`}
                  >
                    RBAC Audit
                  </button>
                </div>

                {/* Tab Contents */}
                {hrmsTab === 'attendance' && (
                  <div className="flex flex-col gap-2 py-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#e3e1e9]">
                        Daily Check-in Geofence
                      </span>
                      <span className="text-[color:var(--accent)] font-mono">100% Verified</span>
                    </div>
                    <div className="w-full bg-[#292a2f] h-2 rounded-full overflow-hidden">
                      <div className="bg-[var(--accent)] h-full w-[96%]"></div>
                    </div>
                    <span className="font-mono text-xs text-[#bbcabf]">
                      96 of 100 on-duty personnel marked on time
                    </span>
                  </div>
                )}

                {hrmsTab === 'leave' && (
                  <div className="flex flex-col gap-2 py-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#e3e1e9]">
                        Pending Manager Approval
                      </span>
                      <span className="text-[color:var(--accent-soft)] font-mono">4 Requests</span>
                    </div>
                    <div className="bg-[#292a2f] p-2 rounded text-xs text-[#bbcabf] flex flex-col gap-1">
                      <div className="flex justify-between">
                        <span>Dev Team — Emergency Leave</span>
                        <span className="text-[color:var(--accent)]">Tier 2 Escalation</span>
                      </div>
                    </div>
                    <span className="font-mono text-xs text-[#bbcabf]">
                      Automated multi-level escalations through Express router
                    </span>
                  </div>
                )}

                {hrmsTab === 'payroll' && (
                  <div className="flex flex-col gap-2 py-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#e3e1e9]">
                        Monthly Salary Computation
                      </span>
                      <span className="text-[color:var(--accent)] font-mono">
                        Deterministic Batch
                      </span>
                    </div>
                    <span className="font-mono text-xs text-[#bbcabf]">
                      Zero discrepancy in tax deduction calculations across
                      multi-state brackets
                    </span>
                  </div>
                )}

                {hrmsTab === 'rbac' && (
                  <div className="flex flex-col gap-2 py-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#e3e1e9]">
                        Granular Roles Matrix
                      </span>
                      <span className="text-[color:var(--accent)] font-mono">
                        Admin / Manager / Staff
                      </span>
                    </div>
                    <span className="font-mono text-xs text-[#bbcabf]">
                      Enforced via middleware JWT claims validation and database
                      row-level policies
                    </span>
                  </div>
                )}
              </div>
            </div>


  );
}
