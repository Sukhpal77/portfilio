import React from 'react';
import { DEMOS, DemoId } from '../data/demos';
import { PlaygroundSection } from './PlaygroundSection';
import { LogIQDemo } from './LogIQDemo';
import { HRMSDemo } from './HRMSDemo';

interface SystemsLabProps {
  activeDemo: DemoId;
  onSelectDemo: (demo: DemoId) => void;
}

export function SystemsLabSection({ activeDemo, onSelectDemo }: SystemsLabProps) {
  const handleTabKey = (event: React.KeyboardEvent<HTMLButtonElement>, index: number) => {
    let next = index;
    if (event.key === 'ArrowRight') next = (index + 1) % DEMOS.length;
    else if (event.key === 'ArrowLeft') next = (index + DEMOS.length - 1) % DEMOS.length;
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = DEMOS.length - 1;
    else return;
    event.preventDefault();
    onSelectDemo(DEMOS[next].id);
    event.currentTarget.parentElement?.querySelector<HTMLButtonElement>(`#lab-tab-${DEMOS[next].id}`)?.focus();
  };

  return (
    <section id="playground" className="py-16">
      <div className="flex flex-col gap-3 mb-8">
        <span className="font-mono text-[11px] text-[color:var(--accent)] uppercase tracking-wider">INTERACTIVE SHOWCASE / EXPLORE THE BUILD</span>
        <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight">The Systems Lab</h2>
        <p className="text-[#bbcabf] max-w-2xl leading-relaxed">Go beyond the project cards. Trace an AI request, investigate a sample incident, or explore an HR workflow.</p>
      </div>
      <div className="bg-[#0d0e13] border border-white/[0.08] rounded-2xl overflow-hidden shadow-2xl">
        <div className="p-4 sm:p-6 border-b border-white/[0.08]">
          <div role="tablist" aria-label="Project demos" className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {DEMOS.map(({ id, label, icon }, index) => (
              <button key={id} id={`lab-tab-${id}`} type="button" role="tab" aria-selected={activeDemo === id} aria-controls={`lab-panel-${id}`} tabIndex={activeDemo === id ? 0 : -1} onKeyDown={(event) => handleTabKey(event, index)} onClick={() => onSelectDemo(id)}
                className={`flex items-center gap-3 text-left px-4 py-3 rounded-xl border ${activeDemo === id ? 'bg-[var(--accent)]/10 border-[var(--accent)]/40 text-[color:var(--accent)]' : 'bg-[#1e1f25] border-white/[0.06] text-[#bbcabf] hover:text-white'}`}>
                <span className="material-symbols-outlined text-[20px]" aria-hidden="true">{icon}</span>
                <span className="text-sm font-medium">{label}</span>
              </button>
            ))}
          </div>
          <p className="font-mono text-[10px] text-[#bbcabf] mt-4">BROWSER SIMULATIONS · FICTIONAL SAMPLE DATA</p>
        </div>
        <div id={`lab-panel-${activeDemo}`} role="tabpanel" aria-labelledby={`lab-tab-${activeDemo}`} tabIndex={0} className="p-4 sm:p-6 lg:p-8 lg:min-h-[440px]">
          {activeDemo === 'pipeline' && <PlaygroundSection />}
          {activeDemo === 'logiq' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <div className="lg:col-span-5 flex flex-col gap-4">
                <span className="font-mono text-[11px] text-[color:var(--accent)] uppercase tracking-wider">LOGIQ / INCIDENT ANALYSIS</span>
                <h3 className="text-2xl font-semibold">Follow the evidence.</h3>
                <p className="text-sm text-[#bbcabf] leading-relaxed">Watch sample request logs develop into a latency spike and a connection timeout. Run the demo to see the evidence and a possible explanation.</p>
                <div className="grid grid-cols-3 gap-2 font-mono text-[11px]">
                  {['Collect', 'Detect', 'Investigate'].map((step, index) => <div key={step} className="rounded-lg bg-[#1e1f25] p-3"><span className="block text-[color:var(--accent)] mb-2">0{index + 1}</span>{step}</div>)}
                </div>
              </div>
              <div className="lg:col-span-7"><LogIQDemo /></div>
            </div>
          )}
          {activeDemo === 'hrms' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <div className="lg:col-span-5 flex flex-col gap-4">
                <span className="font-mono text-[11px] text-[color:var(--accent)] uppercase tracking-wider">ENTERPRISE HRMS / WORKSPACE PREVIEW</span>
                <h3 className="text-2xl font-semibold">Explore the daily workflow.</h3>
                <p className="text-sm text-[#bbcabf] leading-relaxed">Switch between attendance, leave approvals, payroll, and access roles to preview the modules in a sample HR workspace.</p>
              </div>
              <div className="lg:col-span-7"><HRMSDemo /></div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
